# Copy source code for mbedTLS into this directory
# The SDK was tested internally with mbedTLS v2.1.1 which can be found here - https://github.com/ARMmbed/mbedtls/releases/tag/mbedtls-2.1.1