This directory should contain the following files before running make:

  root-CA.crt
  certificate.pem.crt
  private.pem.key
